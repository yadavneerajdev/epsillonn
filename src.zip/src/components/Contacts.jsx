import React from 'react'
import Navbar from './Navbar'

const Contacts = () => {
  return (
    <>
    {/* <Navbar /> */}
    <div>Contacts</div>
    </>
  )
}

export default Contacts