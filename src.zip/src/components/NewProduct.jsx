import React from 'react'
import Navbar from './Navbar'

const NewProduct = () => {
  return (
    <>
        <Navbar header="NEW PRODUCT" link1="All" link2="Red" link3="Green" link4="Blue" link5="Yellow"  />
    </>
  )
}

export default NewProduct