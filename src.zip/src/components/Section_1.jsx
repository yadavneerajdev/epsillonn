import React from 'react'
import Banner from './Banner'
// import CustomNav from './CustomNav'
import './Section_1.css'

const Section_1 = () => {
  return (
    <>
        {/* <CustomNav header="epsillonn" link1="Home" link2="About" link3="Shop" link4="Blog" link5="Contacts" link6="Cart" login="Login/Sign up" /> */}
        {/* <Banner /> */}
    </>
  )
}

export default Section_1