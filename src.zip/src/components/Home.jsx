import React from 'react'
import Carousel from './Carousel'
import Section_1 from './Section_1'






const Home = () => {
  return (
    <>
    <Carousel />
    {/* <Section_1 /> */}
    </>
  )
}

export default Home