import React from 'react'
import './Sidebar.css'
import { useState } from 'react'
// import Slider from 'react-smooth-range-input'; 

const Sidebar_m = ({func, funcPrice}) => {

  const [rangeVal, setRangeVal] = useState(0)



  


  return (
    <>
        <div className="sidebar-cont">
          <div className="sidebar-fil-input">
          <p>{rangeVal}</p>
          <input type="range" className='fir-range' min={0} max={2500} onChange={(e) => (funcPrice(e.target.value) || setRangeVal(e.target.value)) }/>
          </div>
            <button onClick={() => func("All")} className='sidebar-btn'>All</button>
            <button onClick={() => func("kurta")} className='sidebar-btn'>kurta</button>
            <button onClick={() => func("shirt")} className='sidebar-btn'>shirt</button>
            <button onClick={() => func("blue")} className='sidebar-btn'>Blue</button>
            <button onClick={() => func("yellow")} className='sidebar-btn'>Yellow</button>
            {/* <button onClick={() => func("men")} className='sidebar-btn'>women</button> */}
        </div>
    </>
  )
}

export default Sidebar_m