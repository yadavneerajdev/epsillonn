import React from 'react'
import Navbar from './Navbar'

const Blog = () => {
  return (
    <>
    {/* <Navbar /> */}
    <div>Blog</div>
    </>
  )
}

export default Blog