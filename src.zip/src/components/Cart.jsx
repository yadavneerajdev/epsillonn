import React from 'react'
import Navbar from './Navbar'

const Cart = () => {
  return (
    <>
    {/* <Navbar />p */}
    <div>Cart</div>
    </>
  )
}

export default Cart