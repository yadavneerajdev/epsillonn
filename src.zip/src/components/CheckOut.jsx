import React from 'react'

export default function CheckOut() {
  return (
    <div>CheckOut</div>
  )
}
